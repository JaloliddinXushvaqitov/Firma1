package com.example.firma.Service;

import com.example.firma.DTO.APIResponse;
import com.example.firma.DTO.BolimDTO;
import com.example.firma.Entite.Bolim;
import com.example.firma.Entite.Firma;
import com.example.firma.Entite.Ishchi;
import com.example.firma.Repozitary.BolimRepozitary;
import com.example.firma.Repozitary.FirmaRepozitary;
import com.example.firma.Repozitary.IshchiRepozitary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BolimService {
    @Autowired
    BolimRepozitary bolimRepozitary;
    @Autowired
    IshchiRepozitary ishchiRepozitary;

    public APIResponse postbolim(BolimDTO bolimDTO) {
        Ishchi ishchi=new Ishchi();
        ishchi.setIsmi(bolimDTO.getIsmi());
        ishchi.setTelRaqam(bolimDTO.getTelRaqam());
        Ishchi save = ishchiRepozitary.save(ishchi);
        Bolim bolim=new Bolim();
        bolim.setNomi(bolimDTO.getNomi());
        bolim.setIshchi(save);
        bolimRepozitary.save(bolim);
        return new APIResponse("Malumot salandi",true);
    }
}
