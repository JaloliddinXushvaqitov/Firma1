package com.example.firma.Service;

import org.springframework.stereotype.Service;

@Service
public class IshchiService {
}
