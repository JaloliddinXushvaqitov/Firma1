package com.example.firma.DTO;

import lombok.Data;

import javax.persistence.Column;

@Data
public class Manzil_Dto {

    private String viloyat;
    private String tuman;
    private String kocha;
}
