package com.example.firma.DTO;

import lombok.Data;

@Data
public class BolimDTO {
    private String nomi;
    private String ismi;
    private String telRaqam;
}
