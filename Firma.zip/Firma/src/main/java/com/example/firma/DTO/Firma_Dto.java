package com.example.firma.DTO;

import com.example.firma.Entite.Manzil;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.OneToOne;

@Data
public class Firma_Dto {

    private String firmaNomi;
    private String driktorNomi;
    //@OneToOne
    private String viloyat;
    private String tuman;
    private String kocha;
}
