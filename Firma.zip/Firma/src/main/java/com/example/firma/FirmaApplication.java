package com.example.firma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirmaApplication {

    public static void main(String[] args) {
        SpringApplication.run(FirmaApplication.class, args);
    }

}
